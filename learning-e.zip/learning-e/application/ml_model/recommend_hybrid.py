import sys
import pandas as pd
import json

student_id = int(sys.argv[1])
score = float(sys.argv[2])

# Load data
courses_df = pd.read_csv('application/csv/courses.csv')
results_df = pd.read_csv('application/csv/exam_results.csv')

# Content-based: recommend courses based on score threshold
content_based = courses_df[courses_df['difficulty_score'] <= score + 10]['id'].tolist()

# Collaborative: similar students
similar_students = results_df[results_df['score'] >= score - 10]
collab_course_ids = similar_students['exam_id'].value_counts().index.tolist()

# Merge & deduplicate
hybrid_ids = list(set(content_based + collab_course_ids))[:10]

# Output as JSON
print(json.dumps(hybrid_ids))
