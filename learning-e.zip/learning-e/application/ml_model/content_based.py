import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel
import sys
import json

# Load the CSV exported from CodeIgniter
courses = pd.read_csv("ml_data/courses.csv")

# Vectorize the course descriptions
tfidf = TfidfVectorizer(stop_words='english')
tfidf_matrix = tfidf.fit_transform(courses['description'].fillna(""))

# Compute cosine similarity
cosine_sim = linear_kernel(tfidf_matrix, tfidf_matrix)

# Recommend courses
def recommend(course_id, top_n=5):
    idx = courses[courses['id'] == int(course_id)].index[0]
    sim_scores = list(enumerate(cosine_sim[idx]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
    sim_scores = sim_scores[1:top_n+1]
    course_indices = [i[0] for i in sim_scores]
    return courses.iloc[course_indices][['id', 'title']].to_dict(orient='records')

# Get input from PHP (sys.argv)
course_id = sys.argv[1]
recommendations = recommend(course_id)

# Output JSON to PHP
print(json.dumps(recommendations))
