import pandas as pd
import sys
import json
from sklearn.metrics.pairwise import cosine_similarity

# Handle missing input
if len(sys.argv) < 2:
    print(json.dumps([]))
    sys.exit(0)

student_id = int(sys.argv[1])

# Load data
try:
    courses = pd.read_csv('ml_data/courses.csv')
    exams = pd.read_csv('ml_data/exams.csv')
    results = pd.read_csv('ml_data/student_results.csv')
except:
    print(json.dumps([]))
    sys.exit(0)

# Merge to get course_id
results = results.merge(exams, on="exam_id")

# Create interaction matrix: rows=student_id, columns=course_id
interaction_matrix = results.pivot_table(
    index="student_id", columns="course_id", values="score", fill_value=0
)

if student_id not in interaction_matrix.index:
    print(json.dumps([]))
    sys.exit(0)

# Compute cosine similarity
similarity = cosine_similarity(interaction_matrix)
student_idx = list(interaction_matrix.index).index(student_id)
similar_scores = list(enumerate(similarity[student_idx]))
similar_scores = sorted(similar_scores, key=lambda x: x[1], reverse=True)

# Top 3 similar users (excluding self)
top_users = [interaction_matrix.index[i] for i, _ in similar_scores[1:4]]

# Mean preference of top similar users
top_user_data = interaction_matrix.loc[top_users]
mean_scores = top_user_data.mean().sort_values(ascending=False)

# Filter out already seen courses
student_scores = interaction_matrix.loc[student_id]
seen_courses = student_scores[student_scores > 0].index
recommend_ids = [cid for cid in mean_scores.index if cid not in seen_courses][:5]

# Final recommendations
recommended_courses = courses[courses["id"].isin(recommend_ids)][["id", "title", "description"]]
print(recommended_courses.to_json(orient="records"))
