
import pandas as pd
import sys
import json
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Handle missing input
if len(sys.argv) < 2:
    print(json.dumps([]))
    sys.exit(0)

student_id = int(sys.argv[1])

# Load datasets
try:
    courses = pd.read_csv('ml_data/courses.csv')
    exams = pd.read_csv('ml_data/exams.csv')
    results = pd.read_csv('ml_data/student_results.csv')
except Exception as e:
    print(json.dumps([]))
    sys.exit(0)

# Join student results with exams to get course_id
results = results.merge(exams, on='exam_id')

# Filter this student's results
student_results = results[results['student_id'] == student_id]
if student_results.empty:
    print(json.dumps([]))
    sys.exit(0)

# Get top scored course by this student
top_result = student_results.sort_values(by='score', ascending=False).iloc[0]
top_course_id = top_result['course_id']

# Get top course data
filtered = courses[courses['id'] == top_course_id]
if filtered.empty:
    print(json.dumps([]))
    sys.exit(0)

top_course = filtered.iloc[0]

# Compute TF-IDF similarity
tfidf = TfidfVectorizer(stop_words='english')
tfidf_matrix = tfidf.fit_transform(courses['description'].fillna(""))

idx = courses[courses['id'] == top_course_id].index[0]
cosine_sim = cosine_similarity(tfidf_matrix[idx], tfidf_matrix).flatten()

# Get top 5 similar courses (excluding itself)
similar_indices = cosine_sim.argsort()[-6:-1][::-1]
recommended_courses = courses.iloc[similar_indices]

# Fallback: random sample if similarity fails
if recommended_courses.empty:
    recommended_courses = courses[courses['id'] != top_course_id].sample(min(3, len(courses) - 1))

# Output result
print(recommended_courses[['id', 'title', 'description']].to_json(orient='records'))
