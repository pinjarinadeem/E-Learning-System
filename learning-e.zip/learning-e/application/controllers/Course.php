<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Course extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Course_model');
        $this->load->model('Recommendation_model');
    }

    public function dashboard() {
        $data['courses'] = $this->Course_model->get_all_courses();
        $data['projects'] = $this->Course_model->get_all_projects();
        $this->load->view('dashboard', $data);
    }

    public function view($course_id) {
        $data['course'] = $this->Course_model->get_course($course_id);
        $this->load->view('student/course_view', $data);
    }

    public function enroll($course_id) {
        // Check if the user is logged in
        if (!$this->session->userdata('student_id')) {
            redirect('student/login');
        }
    
        // Load models
        $this->load->model('Course_model');
    
        // Get course details
        $data['course'] = $this->Course_model->get_project($course_id);
        $data['projects'] = $this->Course_model->get_projects_by_course($course_id); // Fetch projects
    
        // Load the view
        $this->load->view('course_enroll', $data);
    }
    

    public function take_exam($course_id) {
        // Load the exam form if the request is a GET
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $data['course_id'] = $course_id;
            $this->load->view('exam_page', $data);
        }
    
        // Handle form submission and result processing
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $answer_key = [
                'q1' => 'b',
                'q2' => 'c',
                'q3' => 'a',
                'q4' => 'c',
                'q5' => 'a'
            ];
    
            $score = 0;
            $total_questions = count($answer_key);
    
            // Calculate the score
            foreach ($answer_key as $question => $correct_answer) {
                if ($this->input->post($question) === $correct_answer) {
                    $score++;
                }
            }
    
            $percentage = ($score / $total_questions) * 100;
    
            $data = [
                'student_id' => $this->session->userdata('student_id'),
                'course_id' => $this->input->post('course_id'),
                'score' => $percentage
            ];
    
            $this->Course_model->save_exam_result($data);
    
            // Generate recommendations
            if ($percentage >= 65) {
                $data['recommendations'] = $this->Recommendation_model->collaborative_filtering($data['student_id']);
                $data['result_message'] = "Congratulations! You scored $percentage%. We recommend these courses:";
            } else {
                $data['recommendations'] = $this->Recommendation_model->content_based_filtering($data['student_id'], $data['course_id']);
                $data['result_message'] = "You scored $percentage%. Don't worry, here are courses to improve your skills:";
            }

            
    
            // Load result and recommendation view
            $this->load->view('exam_result', $data);
        }
    }

    public function exam_result() {
        // Define the correct answers for the exam
        $correct_answers = [
            'q1' => 'a',
            'q2' => 'c',
            'q3' => 'b',
            'q4' => 'd',
            'q5' => 'a',
        ];
    
        // Get user answers from the form submission
        $user_answers = $this->input->post();
    
        // Calculate the score
        $total_questions = count($correct_answers);
        $correct_count = 0;
    
        foreach ($correct_answers as $question => $correct_answer) {
            if (isset($user_answers[$question]) && $user_answers[$question] === $correct_answer) {
                $correct_count++;
            }
        }
    
        // Calculate percentage score
        $score = ($correct_count / $total_questions) * 100;
    
        // Static course recommendations
        $collaborative_courses = [
            ['title' => 'Advanced CSS', 'description' => 'Master CSS for beautiful designs.', 'id' => 2],
            ['title' => 'JavaScript Essentials', 'description' => 'Learn JavaScript from scratch.', 'id' => 3],
        ];
    
        $content_based_courses = [
            ['title' => 'HTML Best Practices', 'description' => 'Advanced techniques for HTML.', 'id' => 4],
            ['title' => 'Semantic HTML Mastery', 'description' => 'Learn semantic HTML.', 'id' => 5],
        ];
    
        $result_message = $score >= 65 ? 
            "Congratulations! You passed with a score of $score%. Here are recommended advanced courses:" : 
            "You scored $score%. Consider improving with these foundational courses:";
    
        $recommendations = ($score >= 65) ? $collaborative_courses : $content_based_courses;
    
        $data = [
            'result_message' => $result_message,
            'recommendations' => $recommendations,
        ];
    
        $this->load->view('exam_result', $data);
    }
    
    

    public function save_recommendation($student_id, $course_id, $recommendation_type, $recommended_course_id) {
        $data = [
            'student_id' => $student_id,
            'course_id' => $course_id,
            'recommended_course_id' => $recommended_course_id,
            'recommendation_type' => $recommendation_type
        ];
        $this->db->insert('recommendations', $data);
    }
    

    private function calculate_score($post) {
        // Implement your actual scoring logic here
        return rand(50, 100); // Example random score
    }
}