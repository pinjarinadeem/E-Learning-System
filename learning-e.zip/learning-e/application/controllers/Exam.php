<?php
class Exam extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('Exam_model');
        $this->load->model('Course_model');
        $this->load->library('session');
    }

    // Admin: Add Exam
    public function add_exam() {
        $this->_check_admin();
        if ($this->input->post()) {
            $exam_data = array(
                'course_id' => $this->input->post('course_id'),
                'exam_title' => $this->input->post('exam_title'),
                'time_limit' => $this->input->post('time_limit'),
            );
            $exam_id = $this->Exam_model->add_exam($exam_data);
            
            foreach ($this->input->post('questions') as $question) {
                $this->Exam_model->add_question($exam_id, $question);
            }
            
            $this->session->set_flashdata('success', 'Exam added successfully');
            redirect('admin/exams');
        }
        $data['courses'] = $this->Course_model->get_all_courses();
        $this->load->view('admin/add_exam', $data);
    }

    // Student: Take Exam
    public function take_exam($course_id) {
        $this->_check_student();
        $data['exam'] = $this->Exam_model->get_exam_by_course($course_id);
        $data['questions'] = $this->Exam_model->get_questions($data['exam']->id);
        $this->load->view('student/take_exam', $data);
    }

    // Student: Submit Exam
    public function submit_exam() {
        $this->_check_student();
        $exam_id = $this->input->post('exam_id');
        $score = $this->Exam_model->calculate_score($exam_id, $this->input->post('answers'));
        
        if ($score >= 60) {
            $data['recommended_courses'] = $this->Course_model->recommend_collaborative();
        } else {
            $data['recommended_courses'] = $this->Course_model->recommend_content_based();
        }
        
        $data['score'] = $score;
        $this->load->view('student/exam_result', $data);
    }

    private function _check_admin() {
        if (!$this->session->userdata('admin_logged_in')) redirect('admin/login');
    }
    
    private function _check_student() {
        if (!$this->session->userdata('student_logged_in')) redirect('student/login');
    }
}

?>
