<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Course extends CI_Controller {

    public function __construct() {
        parent::__construct();
        // Load URL helper if not autoloaded
        $this->load->helper('url');
        // Load the model that handles courses if you have one
        $this->load->model('course_model');
    }

    public function add() {
        // Load the upload library
        $this->load->library('upload');

        // Configure upload settings
        $config['upload_path']   = './uploads/courses/';
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['max_size']      = 2048; // 2MB
        $config['encrypt_name']  = TRUE; // Optional: encrypt the file name for security

        $this->upload->initialize($config);

        // Check if a file was selected for upload
        if ( ! empty($_FILES['image']['name'])) {
            if ( ! $this->upload->do_upload('image')) {
                // If upload fails, capture the error message
                $error = $this->upload->display_errors();
                // You can load the view with error messages or set flash data to show the error
                $data['error'] = $error;
                $this->load->view('course_form', $data);
                return;
            } else {
                // If upload is successful, get upload data
                $uploadData = $this->upload->data();
                $imageName = $uploadData['file_name'];
            }
        } else {
            // No image was uploaded; you can assign a default image or leave it empty
            $imageName = '';
        }

        // Prepare the data for insertion
        $courseData = array(
            'title'       => $this->input->post('title'),
            'description' => $this->input->post('description'),
            'video_path'  => $this->input->post('video_path'),
            'tags'        => $this->input->post('tags'),
            'image'       => $imageName
        );

        // Insert data into the database via your model (course_model)
        if ($this->course_model->insert_course($courseData)) {
            // Redirect or load a success view
            redirect('course/list');
        } else {
            // Handle the insertion error as needed
            echo "There was an error saving the course.";
        }
    }
}
