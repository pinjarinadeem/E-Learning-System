<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Clientdash extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Client_model');
        $this->load->model('Project_model');
        $this->load->model('Proposal_model');
        if (!$this->session->userdata('client_id')) {
            redirect('user/login');
        }
    }

    public function dashboard() {
        $data['profile'] = $this->Client_model->get_client($this->session->userdata('client_id'));
        $data['projects'] = $this->Project_model->get_projects_by_client($this->session->userdata('client_id'));
        $data['proposals'] = $this->Proposal_model->get_proposals_by_client($this->session->userdata('client_id'));
        $data['wallet_balance'] = $this->Client_model->get_wallet_balance($this->session->userdata('client_id'));
        $this->load->view('client_dashboard', $data);
    }

    public function add_project() {
        if ($this->input->post()) {
            $data = [
                'client_id' => $this->session->userdata('client_id'),
                'name' => $this->input->post('project_name'),
                'details' => $this->input->post('project_details'),
                'budget' => $this->input->post('project_budget'),
            ];
            $this->Project_model->add_project($data);
            redirect('client/dashboard');
        }
    }

    public function manage_wallet() {
        if ($this->input->post()) {
            $amount = $this->input->post('amount');
            $this->Client_model->add_to_wallet($this->session->userdata('client_id'), $amount);
        }
        redirect('client/dashboard');
    }
}
