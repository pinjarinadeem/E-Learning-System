<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Freelancer_controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Freelancer_model');
        $this->load->library('form_validation');
        $this->load->helper('url');
        $this->load->model('course_model');
    }

    // FREELANCER REGISTRATION
    public function register() {
        $this->form_validation->set_rules('full_name', 'Full Name', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[freelancers.email]');
        $this->form_validation->set_rules('contact_number', 'Contact Number', 'required');
        $this->form_validation->set_rules('skills', 'Skills', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
        $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');

        if ($this->form_validation->run() === FALSE) {
            $this->load->view('freelancer_register');
        } else {
            $data = [
                'full_name' => $this->input->post('full_name'),
                'email' => $this->input->post('email'),
                'contact_number' => $this->input->post('contact_number'),
                'skills' => $this->input->post('skills'),
                'status' => "inactive",
                'password' => password_hash($this->input->post('password'), PASSWORD_BCRYPT)
            ];
            $this->Freelancer_model->register($data);
            redirect('freelancer_controller/login');
        }
    }

    // FREELANCER LOGIN
    public function login() {
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() === FALSE) {
            $this->load->view('freelancer_login');
        } else {
            $email = $this->input->post('email');
            $password = $this->input->post('password');

            $freelancer = $this->Freelancer_model->authenticate($email, $password);
            if ($freelancer) {
                $this->session->set_userdata(['freelancer_id' => $freelancer->id, 'freelancer_name' => $freelancer->full_name]);
                redirect('freelancer_controller/dashboard');
            } else {
                $this->session->set_flashdata('error', 'Invalid email or password');
                redirect('freelancer_controller/login');
            }
        }
    }

    // FREELANCER DASHBOARD
   public function dashboard() {
    // Check session for freelancer ID
    if (!$this->session->userdata('freelancer_id')) {
        redirect('freelancer_controller/login');
    }

    // Load the model
    $this->load->model('Freelancer_model');

    // Session data
    $freelancer_id = $this->session->userdata('freelancer_id');
    $data['freelancer_name'] = $this->session->userdata('freelancer_name');

    // Fetch profile
    $data['profile'] = $this->Freelancer_model->get_profile($freelancer_id);

    // Fetch all active projects
    $data['projects'] = $this->Freelancer_model->get_all_projects();

    // Pass all data to the view
    $this->load->view('freelancer_dashboard', $data);
}

public function zoom_projects() {
    // Load the model
    $this->load->model('Freelancer_model');

    // Fetch all projects
    $data['projects'] = $this->Freelancer_model->get_all_projects();

    // Load the view and pass the data
    $this->load->view('full_project', $data);
}



    public function view_projects() {
        // Load the Freelancer model
        $this->load->model('Freelancer_model');
    
        // Fetch all projects from the model
        $data['projects'] = $this->Freelancer_model->get_all_projects();
        
        echo "<pre>";
        print_r($data['projects']);
        die;
    
        // Load the freelancer dashboard view and pass the projects
        $this->load->view('freelancer_dashboard', $data);
    }
    

    

    public function submit_bid() {
        // Ensure the user is logged in as a freelancer
        if (!$this->session->userdata('freelancer_id')) {
            redirect('login');
        }


        $this->load->model('Freelancer_model');

        

        // Get bid data from POST request
        $data = [
            'project_id'    => $this->input->post('project_id'),
            'freelancer_id' => $this->session->userdata('freelancer_id'),
            'client_id'     => $this->input->post('client_id'),
            'bid_amount'    => $this->input->post('bid_amount'),
            'bid_message'   => $this->input->post('bid_message'),
            'status'        => 'pending'
        ];
        // print_r($data);
        // die;

        // Insert bid into database
        $this->Freelancer_model->insert_bid($data);

        // Redirect back to project page
        $this->session->set_flashdata('success', 'Bid submitted successfully.');
        redirect('freelancer_controller/zoom_projects/' . $data['project_id']);
    }

    public function add() {
        // Load the upload library
        $this->load->library('upload');

        // Configure upload settings
        $config['upload_path']   = './uploads/courses/';
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['max_size']      = 2048; // 2MB
        $config['encrypt_name']  = TRUE; // Optional: encrypt the file name for security

        $this->upload->initialize($config);

        // Check if a file was selected for upload
        if ( ! empty($_FILES['image']['name'])) {
            if ( ! $this->upload->do_upload('image')) {
                // If upload fails, capture the error message
                $error = $this->upload->display_errors();
                // You can load the view with error messages or set flash data to show the error
                $data['error'] = $error;
                $this->load->view('course_form', $data);
                return;
            } else {
                // If upload is successful, get upload data
                $uploadData = $this->upload->data();
                $imageName = $uploadData['file_name'];
            }
        } else {
            // No image was uploaded; you can assign a default image or leave it empty
            $imageName = '';
        }

        // Prepare the data for insertion
        $courseData = array(
            'title'       => $this->input->post('title'),
            'description' => $this->input->post('description'),
            'video_path'  => $this->input->post('video_path'),
            'tags'        => $this->input->post('tags'),
            'image'       => $imageName
        );

        // Insert data into the database via your model (course_model)
        if ($this->course_model->insert_course($courseData)) {
            // Redirect or load a success view
            redirect('course/list');
        } else {
            // Handle the insertion error as needed
            echo "There was an error saving the course.";
        }
    }


    

    // LOGOUT
    public function logout() {
        $this->session->unset_userdata('freelancer_id');
        $this->session->unset_userdata('freelancer_name');
        redirect('freelancer_controller/login');
    }
}
