<?php
defined('BASEPATH') or exit('No direct script access allowed');

class FreelancerDashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Freelancer_model');
    }

    // Dashboard index
    public function index()
    {
        $data['projects'] = $this->Freelancer_model->get_published_projects();
        $data['wallet_balance'] = $this->Freelancer_model->get_wallet_balance($this->session->userdata('freelancer_id'));
        $this->load->view('freelancer_dashboard', $data);
    }

    // Place a bid on a project
    public function place_bid()
    {
        $freelancer_id = $this->session->userdata('freelancer_id');
        $project_id = $this->input->post('project_id');
        $bid_amount = $this->input->post('bid_amount');

        if ($this->Freelancer_model->place_bid($freelancer_id, $project_id, $bid_amount)) {
            $this->session->set_flashdata('success', 'Bid placed successfully.');
        } else {
            $this->session->set_flashdata('error', 'Failed to place bid. Try again.');
        }

        redirect('freelancer_dashboard');
    }

    // Submit completed project
    public function submit_project()
    {
        $freelancer_id = $this->session->userdata('freelancer_id');
        $project_id = $this->input->post('project_id');
        $submission_details = $this->input->post('submission_details');

        if ($this->Freelancer_model->submit_project($freelancer_id, $project_id, $submission_details)) {
            $this->session->set_flashdata('success', 'Project submitted successfully.');
        } else {
            $this->session->set_flashdata('error', 'Failed to submit project. Try again.');
        }

        redirect('freelancer_dashboard');
    }

    // Withdraw funds from wallet
    public function withdraw()
    {
        $freelancer_id = $this->session->userdata('freelancer_id');
        $amount = $this->input->post('amount');

        if ($this->Freelancer_model->withdraw_funds($freelancer_id, $amount)) {
            $this->session->set_flashdata('success', 'Withdrawal successful.');
        } else {
            $this->session->set_flashdata('error', 'Withdrawal failed. Check your balance.');
        }

        redirect('freelancer_dashboard');
    }

    // Logout function
    public function logout()
    {
        $this->session->unset_userdata('freelancer_id');
        $this->session->sess_destroy();
        redirect('login');
    }
}
