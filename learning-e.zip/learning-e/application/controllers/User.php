<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Client_model');
        $this->load->model('Freelancer_model');
        $this->load->library('session');
    }

    public function login()
    {
        $email = $this->input->post('email');
        $password = $this->input->post('password');

        // Check in Client_model
        $client = $this->Client_model->get_client($email, $password);

        if ($client) {
            // Set session for client
            $this->session->set_userdata('user_id', $client->id);
            $this->session->set_userdata('user_type', 'client');
            $this->session->set_userdata('user_name', $client->name);
            redirect('client_dashboard');
        }

        // Check in Freelancer_model
        $freelancer = $this->Freelancer_model->get_freelancer($email, $password);

        if ($freelancer) {
            // Set session for freelancer
            $this->session->set_userdata('user_id', $freelancer->id);
            $this->session->set_userdata('user_type', 'freelancer');
            $this->session->set_userdata('user_name', $freelancer->full_name);
            redirect('freelancer_dashboard');
        }

        $this->load->view('login');
   

    }
        
}
