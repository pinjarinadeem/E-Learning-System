<?php
defined('BASEPATH') or exit('No direct script access allowed');

class ClientDashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('ClientModel');
    }

    public function index()
    {
        $data['projects'] = $this->ClientModel->getProjects();
        $data['proposals'] = $this->ClientModel->getProposals();
        $data['wallet_balance'] = $this->ClientModel->getWalletBalance();
        $this->load->view('client_dashboard', $data);
    }

    public function addProject()
    {
        $projectData = [
            'name' => $this->input->post('project_name'),
            'details' => $this->input->post('project_details'),
            'budget' => $this->input->post('project_budget'),
            'client_id' => 1, // Replace with logged-in client ID
        ];
        $this->ClientModel->addProject($projectData);
        redirect('ClientDashboard');
    }

    public function approveProposal($proposalId)
    {
        $this->ClientModel->updateProposalStatus($proposalId, 'Approved');
        redirect('ClientDashboard');
    }

    public function addFunds()
    {
        $amount = $this->input->post('amount');
        $this->ClientModel->addFunds($amount);
        redirect('ClientDashboard');
    }
}
