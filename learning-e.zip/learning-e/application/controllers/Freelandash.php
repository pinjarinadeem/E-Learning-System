<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Freelandash extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Freelancer_model');
        $this->load->model('Project_model');
        $this->load->model('Proposal_model');
        if (!$this->session->userdata('freelancer_id')) {
            redirect('user/login');
        }
    }

    public function dashboard() {
        $data['profile'] = $this->Freelancer_model->get_freelancer($this->session->userdata('freelancer_id'));
        $data['available_projects'] = $this->Project_model->get_all_projects();
        $data['approved_proposals'] = $this->Proposal_model->get_approved_proposals($this->session->userdata('freelancer_id'));
        $data['wallet_balance'] = $this->Freelancer_model->get_wallet_balance($this->session->userdata('freelancer_id'));
        $this->load->view('freelancer_dashboard', $data);
    }

    public function submit_bid($project_id) {
        if ($this->input->post()) {
            $data = [
                'project_id' => $project_id,
                'freelancer_id' => $this->session->userdata('freelancer_id'),
                'bid_amount' => $this->input->post('bid_amount'),
                'message' => $this->input->post('message'),
            ];
            $this->Proposal_model->submit_proposal($data);
            redirect('freelancer/dashboard');
        }
    }
}
