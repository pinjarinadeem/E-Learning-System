<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Client extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->library('form_validation');
    }

    public function register() {
        if ($this->input->post()) {
            $this->form_validation->set_rules('name', 'Client Name', 'required');
            $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[users.email]');
            $this->form_validation->set_rules('company_name', 'Company Name', 'required');
            $this->form_validation->set_rules('contact_number', 'Contact Number', 'required');
            $this->form_validation->set_rules('address', 'Address', 'required');
            $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
            $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');

            if ($this->form_validation->run()) {
                $data = [
                    'user_type' => 'client',
                    'name' => $this->input->post('name'),
                    'email' => $this->input->post('email'),
                    'company_name' => $this->input->post('company_name'),
                    'contact_number' => $this->input->post('contact_number'),
                    'address' => $this->input->post('address'),
                    'status' => "inactive",
                    'password' => password_hash($this->input->post('password'), PASSWORD_BCRYPT)
                ];

                if ($this->User_model->register_user($data)) {
                    $this->session->set_flashdata('success', 'Client registration successful!');
                    redirect('user/login');
                }
            }
        }
        $this->load->view('client_register');
    }
}
