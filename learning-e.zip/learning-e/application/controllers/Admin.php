<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Admin_model');
        $this->load->model('Exam_model');
        $this->load->model('Course_model');
        $this->load->library('form_validation');
        $this->load->library('upload');
        // $this->_check_login();
    }

    public function index() {
        $this->login();
    }

    public function login() {
        if ($this->input->post()) {
            $email = $this->input->post('email');
            $password = $this->input->post('password');
            
            if ($this->Admin_model->login($email, $password)) {
                redirect('admin/dashboard');
            } else {
                $this->session->set_flashdata('error', 'Invalid credentials');
            }
        }
        $this->load->view('admin/login');
    }

    public function dashboard() {
        // $this->_check_login();
        $data['projects'] = $this->Admin_model->get_all_projects();
        $this->load->view('admin/dashboard', $data);
    }

    public function manage_exams() {
        $data['exams'] = $this->Exam_model->get_all_exams();
        $data['courses'] = $this->Course_model->get_all_courses(); // Fetch all courses
        $data['projects'] = $this->Course_model->get_all_projects();
        // echo "<pre>";
        // print_r($data['exams']);
        // die;
        $this->load->view('admin/manage_exams', $data);
    }

    // Add New Exam
    public function add_exam() {
        // $this->_check_login(); // Ensure user authentication
    
        $this->form_validation->set_rules('title', 'Title', 'required');
        $this->form_validation->set_rules('duration', 'Duration', 'required|numeric');
    
        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
        } else {
            $exam_data = array(
                'course_id'  => $this->input->post('course_id'),
                'title'      => $this->input->post('title'),
                'duration'   => $this->input->post('duration'),
                'total_marks' => $this->input->post('total_marks'),
                'created_at' => date('Y-m-d H:i:s')
            );
    
            if ($this->Exam_model->add_exam($exam_data)) {
                $this->session->set_flashdata('success', 'Exam added successfully!');
            } else {
                $this->session->set_flashdata('error', 'Failed to add exam.');
            }
        }
    
        redirect('admin/manage_exams'); // Redirect back to exams list
    }
    

    // Delete Exam
    public function delete_exam($exam_id) {
        if ($this->Exam_model->delete_exam($exam_id)) {
            $this->session->set_flashdata('success', 'Exam deleted successfully.');
        } else {
            $this->session->set_flashdata('error', 'Failed to delete exam.');
        }
        redirect('admin/manage_exams');
    }

    // Add Question to an Exam
    public function add_question() {
        $question_data = array(
            
            'exam_id' => $this->input->post('exam_id'),
            'question_text' => $this->input->post('question_text'),
            'option_a' => $this->input->post('option_a'),
            'option_b' => $this->input->post('option_b'),
            'option_c' => $this->input->post('option_c'),
            'option_d' => $this->input->post('option_d'),
            'correct_option' => $this->input->post('correct_option')
        );
        // print_r($question_data);
        // die;

        if ($this->Exam_model->add_question($question_data)) {
            $this->session->set_flashdata('success', 'Question added successfully!');
        } else {
            $this->session->set_flashdata('error', 'Failed to add question.');
        }
        redirect('admin/manage_exams');
    }

    public function manage_recommendations() {
        $data['projects'] = $this->Admin_model->get_all_projects(); // Fetch all courses
        $data['recommendations'] = $this->Admin_model->get_all_recommendations(); // Fetch recommendations
    
        $this->load->view('admin/manage_recommendations', $data);
    }
    
    public function add_recommendation() {
        $course_id = $this->input->post('course_id');
        $type = $this->input->post('type');
    
        $data = [
            'course_id' => $course_id,
            'type' => $type
        ];
        
        if ($this->Admin_model->insert_recommendation($data)) {
            $this->session->set_flashdata('success', 'Recommendation added successfully!');
        } else {
            $this->session->set_flashdata('error', 'Failed to add recommendation.');
        }
    
        redirect('admin/manage_recommendations');
    }
    

}