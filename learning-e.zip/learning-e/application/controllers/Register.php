<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {

    public function redirectToRegistration() {
        // Get the user type from POST data
        $user_type = $this->input->post('user_type');

        // Redirect to the appropriate registration page
        if ($user_type === 'client') {
            redirect('Client_controller/register');
        } elseif ($user_type === 'freelancer') {
            redirect('Freelancer_controller/register');
        } else {
            // Redirect back to index if no type is selected
            redirect('index');
        }
    }

    public function client_register() {
        // Load the client registration view
        $this->load->view('client_register');
    }

    public function freelancer_register() {
        // Load the freelancer registration view
        $this->load->view('freelancer_register');
    }
}
