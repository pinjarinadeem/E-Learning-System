<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Freelancer extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->library('form_validation');
    }

    public function register() {
        if ($this->input->post()) {
            $this->form_validation->set_rules('name', 'Full Name', 'required');
            $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[users.email]');
            $this->form_validation->set_rules('contact_number', 'Contact Number', 'required');
            $this->form_validation->set_rules('skills', 'Skills', 'required');
            $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
            $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');

            if ($this->form_validation->run()) {
                $data = [
                    'user_type' => 'freelancer',
                    'name' => $this->input->post('name'),
                    'email' => $this->input->post('email'),
                    'contact_number' => $this->input->post('contact_number'),
                    'skills' => $this->input->post('skills'),
                    'password' => password_hash($this->input->post('password'), PASSWORD_BCRYPT)
                ];

                if ($this->User_model->register_user($data)) {
                    $this->session->set_flashdata('success', 'Freelancer registration successful!');
                    redirect('user/login');
                }
            }
        }
        $this->load->view('freelancer_register');
    }
}
