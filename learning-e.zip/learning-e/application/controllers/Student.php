<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Student extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Student_model');
    }

    public function register() {
        $this->load->library('form_validation');
        
        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[students.email]');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
        $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');
    
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('student/register');
        } else {
            $data = array(
                'name' => $this->input->post('name'),
                'email' => $this->input->post('email'),
                'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT)
            );
            $this->Student_model->register($data);
            $this->session->set_flashdata('success', 'Registration successful! Please login.');
            redirect('student/login');
        }
    }
    
    public function login() {
        $this->load->library('form_validation');
    
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required');
    
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('student/login');
        } else {
            $email = $this->input->post('email');
            $password = $this->input->post('password');
            $student = $this->Student_model->login($email, $password);
    
            if ($student) {
                $this->session->set_userdata(array(
                    'student_id' => $student->id,
                    'name' => $student->name,
                    'email' => $student->email
                ));
                redirect('course/dashboard');
            } else {
                $data['error'] = 'Invalid email or password';
                $this->load->view('student/login', $data);
            }
        }
    }

    public function dashboard() {
        // Check if student is logged in
        if (!$this->session->userdata('student_id')) {
            redirect('student/login');
        }
    
        // Load necessary models
        $this->load->model('Course_model');
    
        // Fetch data for the dashboard
        $data['courses'] = $this->Course_model->get_all_courses();
        $data['projects'] = $this->Course_model->get_all_projects();
        
    //     echo "<pre>";
    //     print_r($data['projects']);
    // echo "</pre>";
    // exit();// Fetch projects

        
    
        // Load the dashboard view
        $this->load->view('student/dashboard', $data);
    }


        public function take_exam($exam_id) {
            // $this->_check_login();
            $data['exam'] = $this->Student_model->get_exam($exam_id);
            // print_r($data['exam']);
            // die;
            if(empty($data['exam']))
            {
                $this->load->view('student/no_exam_available');
            }
            $data['questions'] = $this->Student_model->get_exam_questions($exam_id);
            $this->load->view('student/take_exam', $data);
        }
        public function submit_exam() {
            $student_id = $this->session->userdata('student_id');
            $exam_id = $this->input->post('exam_id');
        
            // Check if any answer is selected
            if (empty($this->input->post('answer'))) {
                $this->session->set_flashdata('error', 'You must answer at least one question!');
                redirect('student/take_exam/'.$exam_id);
            }
        
            $total_questions = count($this->input->post('question_ids'));
            $correct_answers = 0;
        
            foreach ($this->input->post('question_ids') as $index => $question_id) {
                $selected_option = $this->input->post('answer')[$index] ?? null; // Avoid undefined index
                $correct_option = $this->Student_model->get_correct_option($question_id);
        
                if ($selected_option === $correct_option) {
                    $correct_answers++;
                }
            }
        
            $score = ($correct_answers / $total_questions) * 100;
        
            $exam_result = [
                'student_id' => $student_id,
                'exam_id' => $exam_id,
                'score' => $correct_answers,
                'total_questions' => $total_questions,
                'percentage' => $score
            ];
            $this->Student_model->save_exam_result($exam_result);
        
            if ($score >= 60) {
                redirect('student/recommend_collaborative');
            } else {
                redirect('student/recommend_content');
            }
        }

        public function test_collab_json() {
    $student_id = 1; // or dynamically: $this->session->userdata('student_id');

    $this->load->model('Student_model');
    $recommended = $this->Student_model->get_collaborative_recommendations($student_id);

    header('Content-Type: application/json');
    echo json_encode($recommended);
}

        
      public function recommend_collaborative() {
    $student_id = $this->session->userdata('student_id');

    $this->load->model('Recommendation_model');
    $this->load->model('Student_model');

    // Export latest data
    $this->Recommendation_model->export_courses_to_csv();
    $this->Recommendation_model->export_exams_to_csv();
    $this->Recommendation_model->export_exam_results_to_csv();

    $recommended_courses = $this->Student_model->get_collaborative_recommendations($student_id);

    $data['recommended_courses'] = $recommended_courses;
    $this->load->view('student/recommend_collaborative', $data);
}


     public function recommend_content() {
    $student_id = $this->session->userdata('student_id');

    $this->load->model('Recommendation_model');
    $this->load->model('Student_model');

    // Export all CSVs
    $this->Recommendation_model->export_courses_to_csv();
    $this->Recommendation_model->export_exams_to_csv();
    $this->Recommendation_model->export_exam_results_to_csv();

    // Run Python ML logic
    $recommended_courses = $this->Student_model->get_ml_recommendations($student_id);

    $data['recommended_courses'] = $recommended_courses;
    $this->load->view('student/recommend_content', $data);
}


        
            

    public function logout() {
        $this->session->unset_userdata('student_id');
        redirect('student/login');
    }
}