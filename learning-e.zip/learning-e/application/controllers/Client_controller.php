<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Client_controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Client_model');
        $this->load->library('form_validation');
        $this->load->model('ClientModel');
    }
    public function index()
    {
        $data['projects'] = $this->ClientModel->getProjects();

        $data['proposals'] = $this->ClientModel->getProposals();
        $data['wallet_balance'] = $this->ClientModel->getWalletBalance($this->session->client_id);
        $this->load->model('Freelancer_model');
        $project_id = $this->session->client_id;
        $data['bids'] = $this->view_bids($project_id);
        // echo '<pre>';
        // print_r($data['projects']);
        // die;
        // print_r($this->session->client_id);
        // die;
        $this->load->view('client_dashboard', $data);
    }

    // CLIENT REGISTRATION
    public function register() {
        $this->form_validation->set_rules('client_name', 'Client Name', 'required');
        $this->form_validation->set_rules('business_email', 'Business Email', 'required|valid_email|is_unique[clients.business_email]');
        $this->form_validation->set_rules('company_name', 'Company Name', 'required');
        $this->form_validation->set_rules('business_contact_number', 'Business Contact Number', 'required');
        $this->form_validation->set_rules('company_address', 'Company Address', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
        $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');

        if ($this->form_validation->run() === FALSE) {
            $this->load->view('client_register');
        } else {
            $data = [
                'client_name' => $this->input->post('client_name'),
                'business_email' => $this->input->post('business_email'),
                'company_name' => $this->input->post('company_name'),
                'client_bal' => 0,
                'business_contact_number' => $this->input->post('business_contact_number'),
                'company_address' => $this->input->post('company_address'),
                'status' => "inactive",
                'password' => password_hash($this->input->post('password'), PASSWORD_BCRYPT)
            ];
            $this->Client_model->register($data);
            redirect('client_controller/login');
        }
    }

    // CLIENT LOGIN
    public function login() {
        $this->form_validation->set_rules('business_email', 'Business Email', 'required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() === FALSE) {
            $this->load->view('client_login');
        } else {
            $email = $this->input->post('business_email');
            $password = $this->input->post('password');

            $client = $this->Client_model->authenticate($email, $password);
            if ($client) {
                $this->session->set_userdata(['client_id' => $client->id, 'client_name' => $client->client_name]);
                
                redirect('client_controller/dashboard');

            } else {
                $this->session->set_flashdata('error', 'Invalid email or password');
                redirect('client_controller/login');
            }
        }
    }

    // CLIENT DASHBOARD
    public function dashboard() {
        if (!$this->session->userdata('client_id')) {
            redirect('client_controller/login');
        }
        $data['client_name'] = $this->session->userdata('client_name');
        $this->load->view('client_dashboard', $data);
    }

    public function addProject()
    {
        $projectData = [
            'name' => $this->input->post('project_name'),
            'details' => $this->input->post('project_details'),
            'budget' => $this->input->post('project_budget'),
            'client_id' => $this->session->client_id, // Replace with logged-in client ID
        ];
        $this->ClientModel->addProject($projectData);
        redirect('client_controller');
    }
    
    public function add_funds()
    {
        $client_id = $this->session->userdata('client_id'); // Get logged-in client's ID
        $amount = $this->input->post('amount'); // Get amount from the input form
    
        // Validate the amount
        if (is_numeric($amount) && $amount > 0) {
            // Call the model function to add funds
            if ($this->ClientModel->add_funds($client_id, $amount)) {
                $this->session->set_flashdata('success', 'Funds added successfully.');
            } else {
                $this->session->set_flashdata('error', 'Failed to add funds. Please try again.');
            }
        } else {
            $this->session->set_flashdata('error', 'Invalid amount. Please enter a valid number.');
        }
    
        redirect('client_controller'); // Redirect to the client dashboard
    }

    public function view_bids($project_id) {
        // if (!$this->session->userdata('client_id')) {
        //     redirect('client_controller/login');
        // }
        // print_r($project_id);
        // die;
    
        $this->load->model('Freelancer_model');
        $data['bids'] = $this->Freelancer_model->get_bids_by_project($project_id);
        return $data['bids'];

        print_r($data['bids']);
        die;
    
        // $this->load->view('client_dashboard', $data);
    }
    
    
    
    public function update_bid_status() {
        if (!$this->session->userdata('client_id')) {
            redirect('login');
        }
    
        $bid_id = $this->input->post('bid_id');
        $status = $this->input->post('status');
    
        $this->load->model('Freelancer_model');
        $this->Freelancer_model->update_bid_status($bid_id, $status);
    
        $this->session->set_flashdata('success', 'Bid status updated.');
        redirect($_SERVER['HTTP_REFERER']);
    }
    
    
    

    // LOGOUT
    public function logout() {
        // print_r("hi");
        // die;
        $this->session->unset_userdata('client_id');
        $this->session->unset_userdata('client_name');
        redirect('client_controller/login');
    }


}
