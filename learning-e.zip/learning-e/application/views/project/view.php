<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $course->title; ?> - Course</title>
    <style>
        /* Basic Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        /* Body Styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            padding: 20px;
            color: #333;
        }
        
        /* Container styling */
        .container {
            max-width: 960px;
            margin: 0 auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        
        /* Header styling */
        .course-header {
            margin-bottom: 20px;
            text-align: center;
        }
        
        .course-header h2 {
            font-size: 2rem;
        }
        
        /* Video styling */
        .course-video {
            text-align: center;
            margin-bottom: 20px;
        }
        
        .course-video iframe {
            width: 100%;
            max-width: 560px;
            height: 315px;
            border: none;
        }
        
        /* Footer and Button styling */
        .course-footer {
            text-align: center;
        }
        
        .btn {
            display: inline-block;
            padding: 12px 20px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            font-size: 1rem;
            transition: background-color 0.3s ease;
        }
        
        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="course-header">
        <h2><?= $course->title; ?></h2>
    </div>
    <div class="course-video">
        <!-- Ensure the video URL is in the embeddable format -->
        <iframe src="https://www.youtube.com/embed/kUMe1FH4CHE" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div>
    <div class="course-footer">
        <!-- Adjust the exam URL as needed -->
        <a href="<?= site_url('Course/take_exam/'.$course->id); ?>" class="btn">Take Exam</a>
    </div>
</div>
</body>
</html>
