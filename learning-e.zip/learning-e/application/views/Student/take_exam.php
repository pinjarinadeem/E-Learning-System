<!DOCTYPE html>
<html>
<head>
    <title>Take Exam</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/exam.css'); ?>">
    <script>
        let timeLeft = <?= $exam->duration * 60 ?>;

        function startTimer() {
            let timer = setInterval(function() {
                document.getElementById("timer").innerText = Math.floor(timeLeft / 60) + ":" + (timeLeft % 60);

                if (timeLeft <= 0) {
                    clearInterval(timer);
                    showTimeUpPopup();
                }
                timeLeft--;
            }, 1000);
        }

        function showTimeUpPopup() {
    alert("Time's up! Redirecting to the dashboard...");
    window.location.href = "<?= site_url('course/dashboard'); ?>";
}


        function validateForm(event) {
            let totalQuestions = document.querySelectorAll('.question-block').length;
            let answered = document.querySelectorAll('input[type="radio"]:checked').length;

            if (answered === 0) {
                alert("You must answer at least one question before submitting!");
                event.preventDefault(); // Prevent form submission
                return false;
            }
        }

        window.onload = startTimer;
    </script>
</head>
<body>
     <!-- Navigation Bar -->
     <nav class="navbar">
        <div class="navbar-brand">
            <img src="<?= base_url('assets/images/logo.jpg') ?>" alt="Logo">
        </div>
        <div class="navbar-links">
            <a href="#" class="active">Home</a>
            <a href="#">My Learning</a>
            <a href="#">Courses</a>
            <a href="#">Careers</a>
        </div>
        <div class="navbar-user">
            <span>Welcome, <?= $this->session->userdata('name') ?></span>
            <a href="<?= site_url('student/logout') ?>" class="logout-btn">Logout</a>
        </div>
    </nav>

    <h2><?= $exam->title ?></h2>
    <p>Time Left: <span id="timer"></span></p>

    <form id="examForm" method="post" action="<?= site_url('student/submit_exam') ?>" onsubmit="return validateForm(event)">
        <input type="hidden" name="exam_id" value="<?= $exam->id ?>">

        <?php foreach ($questions as $index => $q): ?>
            <div class="question-block">
                <p><?= ($index + 1) . ". " . $q->question_text ?></p>
                <input type="hidden" name="question_ids[]" value="<?= $q->id ?>">
                <input type="radio" name="answer[<?= $index ?>]" value="A"> <?= $q->option_a ?><br>
                <input type="radio" name="answer[<?= $index ?>]" value="B"> <?= $q->option_b ?><br>
                <input type="radio" name="answer[<?= $index ?>]" value="C"> <?= $q->option_c ?><br>
                <input type="radio" name="answer[<?= $index ?>]" value="D"> <?= $q->option_d ?><br>
            </div>
        <?php endforeach; ?>

        <button type="submit">Submit Exam</button>
    </form>
</body>
</html>
