<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>No Exam Available</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        .no-exam-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            text-align: center;
        }
    </style>
</head>
<body>

<div class="container no-exam-container">
    <div class="card shadow-lg p-4">
        <h2 class="text-danger">No Exam Available</h2>
        <p class="text-muted">Currently, there are no exams available for this course. Please check back later.</p>
        <a href="<?= base_url('course/dashboard') ?>" class="btn btn-primary">Go Back to Courses</a>
    </div>
</div>

</body>
</html>
