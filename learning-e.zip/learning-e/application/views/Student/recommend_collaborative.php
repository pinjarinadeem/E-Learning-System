<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Recommended Courses - Collaborative</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f4f6f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 960px;
            margin: auto;
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 12px rgba(0,0,0,0.1);
        }
        h2 {
            color: #2c3e50;
            text-align: center;
            margin-bottom: 30px;
        }
        .course-card {
            background-color: #fafafa;
            border: 1px solid #e0e0e0;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            transition: box-shadow 0.2s ease-in-out;
        }
        .course-card:hover {
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        .course-title {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 10px;
            color: #333;
        }
        .course-desc {
            font-size: 15px;
            color: #555;
        }
        .no-recommend {
            text-align: center;
            font-size: 18px;
            color: #888;
            margin-top: 50px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Recommended Courses for You (Collaborative Filtering)</h2>

    <?php if (!empty($recommended_courses)) : ?>
        <?php foreach ($recommended_courses as $course): ?>
            <div class="course-card">
                <div class="course-title"><?= htmlspecialchars($course->title) ?></div>
                <div class="course-desc"><?= nl2br(htmlspecialchars($course->description)) ?></div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="no-recommend">No recommendations found based on similar students.</div>
    <?php endif; ?>
</div>

</body>
</html>
