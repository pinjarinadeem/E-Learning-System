<!DOCTYPE html>
<html>
<head>
    <title>Student Registration</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/register.css'); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h2>Student Registration</h2>
        
        <?php if(isset($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="post">
            <div class="form-group">
                <label>Full Name:</label>
                <input type="text" name="name" required value="<?php echo set_value('name'); ?>">
            </div>

            <div class="form-group">
                <label>Email:</label>
                <input type="email" name="email" required value="<?php echo set_value('email'); ?>">
            </div>

            <div class="form-group">
                <label>Password:</label>
                <input type="password" name="password" required>
            </div>

            <div class="form-group">
                <label>Confirm Password:</label>
                <input type="password" name="confirm_password" required>
            </div>

            <button type="submit">Register</button>
            
            <div class="login-link">
                Already have an account? <a href="<?php echo site_url('student/login'); ?>">Login here</a>
            </div>
        </form>
    </div>
</body>
</html>