<!DOCTYPE html>
<html>
<head>
    <title>Recommended Courses (Content-Based)</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/content.css'); ?>">
</head>
<body>
    <div class="container">
        <h1>Recommended Courses for You</h1>
        <p>Based on your exam performance, these courses will help strengthen your knowledge:</p>

       <?php if (!empty($recommended_courses)): ?>
    <?php foreach ($recommended_courses as $course): ?>
        <div class="course-item">
            <h3><?= $course->title ?></h3>
            <p><?= $course->description ?></p>
        </div>
    <?php endforeach; ?>
<?php else: ?>
    <p>No recommendations found.</p>
<?php endif; ?>

        <a href="<?= site_url('course/dashboard'); ?>" class="btn">Back to Dashboard</a>
    </div>
</body>
</html>
