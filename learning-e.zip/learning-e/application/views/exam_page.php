<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>HTML Exam</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/exam.css'); ?>">
</head>
<body>
<div class="container">
    <h2>HTML Exam</h2>
    <form action="<?php echo site_url('course/exam_result/' . $course_id); ?>" method="POST">
        <input type="hidden" name="course_id" value="<?php echo $course_id; ?>">
        
        <div class="question">
            <p>1. What does HTML stand for?</p>
            <label><input type="radio" name="q1" value="a"> Home Tool Markup Language</label><br>
            <label><input type="radio" name="q1" value="b"> Hyper Text Markup Language</label><br>
            <label><input type="radio" name="q1" value="c"> Hyperlinks Text Markup Language</label><br>
            <label><input type="radio" name="q1" value="d"> Hyper Textual Media Language</label>
        </div>

        <div class="question">
            <p>2. Who is making the Web standards?</p>
            <label><input type="radio" name="q2" value="a"> Google</label><br>
            <label><input type="radio" name="q2" value="b"> Microsoft</label><br>
            <label><input type="radio" name="q2" value="c"> The World Wide Web Consortium</label><br>
            <label><input type="radio" name="q2" value="d"> Mozilla</label>
        </div>

        <div class="question">
            <p>3. Choose the correct HTML element for the largest heading:</p>
            <label><input type="radio" name="q3" value="a"> &lt;h1&gt;</label><br>
            <label><input type="radio" name="q3" value="b"> &lt;h6&gt;</label><br>
            <label><input type="radio" name="q3" value="c"> &lt;heading&gt;</label><br>
            <label><input type="radio" name="q3" value="d"> &lt;head&gt;</label>
        </div>

        <div class="question">
            <p>4. What is the correct HTML element for inserting a line break?</p>
            <label><input type="radio" name="q4" value="a"> &lt;lb&gt;</label><br>
            <label><input type="radio" name="q4" value="b"> &lt;break&gt;</label><br>
            <label><input type="radio" name="q4" value="c"> &lt;br&gt;</label><br>
            <label><input type="radio" name="q4" value="d"> &lt;hr&gt;</label>
        </div>

        <div class="question">
            <p>5. What is the correct HTML for creating a hyperlink?</p>
            <label><input type="radio" name="q5" value="a"> &lt;a href="http://example.com"&gt;example.com&lt;/a&gt;</label><br>
            <label><input type="radio" name="q5" value="b"> &lt;a url="http://example.com"&gt;example.com&lt;/a&gt;</label><br>
            <label><input type="radio" name="q5" value="c"> &lt;a link="http://example.com"&gt;example.com&lt;/a&gt;</label><br>
            <label><input type="radio" name="q5" value="d"> &lt;link&gt;example.com&lt;/link&gt;</label>
        </div>

        <button type="submit" class="btn">Submit Exam</button>
    </form>
</div>
</body>
</html>
