<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="<?php echo site_url('course/add'); ?>" method="post" enctype="multipart/form-data">
    <div>
        <label for="title">Course Title</label>
        <input type="text" name="title" id="title" required>
    </div>
    <div>
        <label for="description">Course Description</label>
        <textarea name="description" id="description" required></textarea>
    </div>
    <div>
        <label for="video_path">Video URL</label>
        <input type="text" name="video_path" id="video_path">
    </div>
    <div>
        <label for="tags">Tags</label>
        <input type="text" name="tags" id="tags">
    </div>
    <div>
        <label for="image">Course Image</label>
        <input type="file" name="image" id="image" accept="image/*">
    </div>
    <button type="submit">Add Course</button>
</form>

</body>
</html>