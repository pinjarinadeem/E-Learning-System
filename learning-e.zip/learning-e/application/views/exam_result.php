<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Exam Result</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/exam_result.css'); ?>">
</head>
<style>
    body {
    font-family: 'Arial', sans-serif;
    background-color: #f9f9f9;
    padding: 20px;
}

.container {
    max-width: 600px;
    margin: 0 auto;
    background: #ffffff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h2 {
    text-align: center;
}

.recommendation-list {
    list-style-type: none;
    padding: 0;
}

.recommendation-list li {
    background: #e9ecef;
    margin-bottom: 15px;
    padding: 15px;
    border-radius: 5px;
}

.recommendation-list li h3 {
    margin: 0 0 5px;
}

.btn {
    display: inline-block;
    padding: 10px 15px;
    background-color: #007bff;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    margin-top: 10px;
}

.btn:hover {
    background-color: #0056b3;
}

</style>
<body>
<div class="container">
    <h2>Exam Result</h2>
    <p><?= $result_message ?></p>

    <ul class="recommendation-list">
        <?php foreach ($recommendations as $course): ?>
            <li>
                <h3><?= $course['title']; ?></h3>
                <p><?= $course['description']; ?></p>
                <a href="<?= site_url('course/view/' . $course['id']); ?>" class="btn">View Course</a>
            </li>
        <?php endforeach; ?>
    </ul>

    <a href="<?= site_url('course/dashboard'); ?>" class="btn">Go to Dashboard</a>
</div>
</body>
</html>
