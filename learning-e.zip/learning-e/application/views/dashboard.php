<!DOCTYPE html>
<html>
<head>
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/projects2.css'); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="navbar-brand">
            <img src="<?= base_url('assets/images/logo.jpg') ?>" alt="Logo">
        </div>
        <div class="navbar-links">
            <a href="#" class="active">Home</a>
            <a href="#">My Learning</a>
            <a href="#">Courses</a>
            <a href="#">Careers</a>
        </div>
        <div class="navbar-user">
            <span>Welcome, <?= $this->session->userdata('name') ?></span>
            <a href="<?= site_url('student/logout') ?>" class="logout-btn">Logout</a>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container">
        <!-- Hero Section -->
        <section class="hero">
            <h1>What do you want to learn today?</h1>
            <p>Explore our featured projects and courses to enhance your skills.</p>
        </section>

        <!-- Featured Projects -->
        <section class="featured-projects">
            <h2>Featured Projects</h2>
            <div class="project-list">
                <?php if (!empty($projects)): ?>
                    <?php foreach ($projects as $project): ?>
                        <div class="project-item">
                            <?php if (!empty($project->image_path)): ?>
                                <img src="<?= base_url($project->image_path) ?>" class="project-image" alt="<?= $project->name ?>">
                            <?php endif; ?>
                            <h3 class="project-title"><?= $project->name ?></h3>
                            <p class="project-description"><?= $project->description ?></p>
                            <a href="<?= site_url('Course/enroll/' . $project->id) ?>" class="btn">View Details</a>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="no-projects">No projects available at the moment.</p>
                <?php endif; ?>
            </div>
        </section>

        <!-- Popular Courses -->
        <section class="popular-courses">
            <h2>Popular Courses</h2>
            <div class="course-list">
                <?php if (!empty($courses)): ?>
                    <?php foreach ($courses as $course): ?>
                        <div class="course-item">
                            <h3 class="course-title"><?= $course->title ?></h3>
                            <p class="course-description"><?= $course->description ?></p>
                            <a href="<?= site_url('course/view/' . $course->id) ?>" class="btn">Start Course</a>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="no-courses">No courses available at the moment.</p>
                <?php endif; ?>
            </div>
        </section>
    </div>
</body>
</html>