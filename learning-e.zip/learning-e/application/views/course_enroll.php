<?php
// Convert YouTube URL to embeddable format
function convertYoutubeURL($url) {
    preg_match("/(youtu\.be\/|youtube\.com\/(watch\?(.*&)?v=|embed\/|v\/))([a-zA-Z0-9_-]{11})/", $url, $matches);
    return isset($matches[4]) ? "https://www.youtube.com/embed/" . $matches[4] : "";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $course->name; ?> - Course</title>
    <style>
        /* Basic Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        /* Body Styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            padding: 20px;
            color: #333;
        }

        .navbar {
    background-color: #ffffff;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0.75rem 2rem;
    position: sticky;
    top: 0;
    z-index: 100;
}

.navbar-brand img {
    height: 50px;
}

.navbar-links a {
    margin: 0 1rem;
    text-decoration: none;
    font-weight: 500;
    color: #333;
    transition: color 0.3s ease;
}

.navbar-links a:hover,
.navbar-links a.active {
    color: #007bff;
}

.navbar-user {
    display: flex;
    align-items: center;
    font-size: 0.9rem;
    color: #555;
}

.navbar-user span {
    margin-right: 1rem;
}

.logout-btn {
    background: #007bff;
    color: #fff;
    padding: 0.5rem 1rem;
    border-radius: 4px;
    text-decoration: none;
    transition: background 0.3s ease;
}

.logout-btn:hover {
    background: #0056b3;
}

        
        /* Container styling */
        .container {
            max-width: 960px;
            margin: 2rem auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        
        /* Header styling */
        .course-header {
            margin-bottom: 20px;
            text-align: center;
        }
        
        .course-header h2 {
            font-size: 2rem;
        }
        
        /* Video styling */
        .course-video {
            text-align: center;
            margin-bottom: 20px;
        }
        
        .course-video iframe {
            width: 100%;
            max-width: 560px;
            height: 315px;
            border: none;
        }
        
        /* Footer and Button styling */
        .course-footer {
            text-align: center;
        }
        
        .btn {
            display: inline-block;
            padding: 12px 20px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            font-size: 1rem;
            transition: background-color 0.3s ease;
        }
        
        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<nav class="navbar">
        <div class="navbar-brand">
            <img src="<?= base_url('assets/images/logo.jpg') ?>" alt="Logo">
        </div>
        <div class="navbar-links">
            <a href="<?= site_url('course/dashboard') ?>" class="active">Home</a>
            <a href="#">My Learning</a>
            <a href="#">Courses</a>
            <a href="#">Careers</a>
        </div>
        <div class="navbar-user">
            <span>Welcome, <?= $this->session->userdata('name') ?></span>
            <a href="<?= site_url('student/logout') ?>" class="logout-btn">Logout</a>
        </div>
    </nav>

<div class="container">
    <div class="course-header">
        <h2><?= $course->name; ?></h2>
    </div>

    <div class="course-video">
        <?php if (!empty($course->video_url)): ?>
            <iframe width="100%" height="400px" 
                src="<?= str_replace("watch?v=", "embed/", $course->video_url); ?>" 
                frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen>
            </iframe>
        <?php else: ?>
            <p>No video available for this course.</p>
        <?php endif; ?>
    </div>

    <div class="course-footer">
        <a href="<?= base_url('Student/take_exam/' . $course->id); ?>" class="btn">Take Exam</a>
    </div>
</div>

</body>
</html>
