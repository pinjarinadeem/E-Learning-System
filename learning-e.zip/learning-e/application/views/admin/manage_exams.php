<!DOCTYPE html>
<html>
<head>
    <title>Manage Exams</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/manage_exam.css'); ?>">
</head>
<body>
    <div class="container">
        <h1>Exam Management</h1>

        <?php if($this->session->flashdata('success')): ?>
            <div class="alert success"><?= $this->session->flashdata('success') ?></div>
        <?php endif; ?>
        <?php if($this->session->flashdata('error')): ?>
            <div class="alert error"><?= $this->session->flashdata('error') ?></div>
        <?php endif; ?>

        <!-- Add Exam Form -->
        <div class="exam-form">
            <h2>Add New Exam</h2>
            <form method="post" action="<?= site_url('admin/add_exam'); ?>">
                <label>Course:</label>
                <select name="course_id" required>
                    <?php foreach ($projects as $project): ?>
                        <option value="<?= $project->id ?>"><?= $project->name ?></option>
                    <?php endforeach; ?>
                </select>
                <!-- <input type="text" name="course_id" value="<?=$projects->$id?>"> -->
                <label>Exam Title:</label>
                <input type="text" name="title" required>

                <label>Time Limit (minutes):</label>
                <input type="number" name="duration" required>

                <label>Total Marks:</label>
                <input type="number" name="total_marks" required>

                <button type="submit">Add Exam</button>
            </form>
        </div>

        <!-- List of Exams -->
        <h2>Existing Exams</h2>
        <table>
            <tr>
                <th>Exam Title</th>
                <th>Course</th>
                <th>Time Limit</th>
                <th>Total Marks</th>
                <th>Actions</th>
            </tr>
            <?php foreach ($exams as $exam): ?>
                <tr>
                    <td><?= $exam->title ?></td>
                    <td><?= $exam->course_id ?></td>
                    <td><?= $exam->duration ?> min</td>
                    <td><?= $exam->total_marks ?></td>
                    <td>
                        <a href="<?= site_url('admin/delete_exam/'.$exam->id); ?>" class="btn delete">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>

        <!-- Add Question Form -->
        <h2>Add Question</h2>
        <form method="post" action="<?= site_url('admin/add_question'); ?>">
            <label>Select Exam:</label>
            <input type="hidden" name="course_id" id="course_id">
            <select name="exam_id" required>
                <?php foreach ($exams as $exam): ?>
                    <option value="<?= $exam->course_id ?>"><?= $exam->title ?></option>
                <?php endforeach; ?>
            </select>

            <label>Question:</label>
            <textarea name="question_text" required></textarea>

            <label>Option A:</label>
            <input type="text" name="option_a" required>

            <label>Option B:</label>
            <input type="text" name="option_b" required>

            <label>Option C:</label>
            <input type="text" name="option_c" required>

            <label>Option D:</label>
            <input type="text" name="option_d" required>

            <label>Correct Option:</label>
            <select name="correct_option" required>
                <option value="A">A</option>
                <option value="B">B</option>
                <option value="C">C</option>
                <option value="D">D</option>
            </select>

            <button type="submit">Add Question</button>
        </form>
    </div>
</body>
</html>
