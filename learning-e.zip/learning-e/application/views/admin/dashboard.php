<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/admin_dashboard2.css'); ?>">
    <style>
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .project-form { margin-bottom: 30px; }
        .project-list { display: grid; gap: 20px; }
        .project-item { border: 1px solid #ddd; padding: 15px; }
        .project-image { max-width: 200px; height: auto; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Admin Dashboard</h1>
        <a href="<?= site_url('admin/logout') ?>">Logout</a>

        <div class="project-form">
            <h2>Add New Project</h2>
            <?php if($this->session->flashdata('success')): ?>
                <div style="color:green"><?= $this->session->flashdata('success') ?></div>
            <?php endif; ?>
            <?php if($this->session->flashdata('error')): ?> 
                <div style="color:red"><?= $this->session->flashdata('error') ?></div>
            <?php endif; ?>
            
            <form method="post" enctype="multipart/form-data" action="<?= site_url('admin/add_project') ?>">
                <div>
                    <input type="text" name="name" placeholder="Project Name" required>
                </div>
                <div>
                    <textarea name="description" placeholder="Project Description" required></textarea>
                </div>
                <div>
                    <input type="text" name="video_url" placeholder="project youtube video url" required>
                </div>
                <div>
                    <input type="file" name="project_image" accept="image/*" required>
                </div>
                <button type="submit">Add Project</button>
            </form>
        </div>

        <div class="project-list">
            <h2>Existing Projects</h2>
            <?php foreach($projects as $project): ?>
                <div class="project-item">
                    <h3><?= $project->name ?></h3>
                    <img src="<?= base_url($project->image_path) ?>" class="project-image">
                    <p><?= $project->description ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>