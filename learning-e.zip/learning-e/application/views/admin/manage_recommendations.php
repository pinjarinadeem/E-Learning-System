<!DOCTYPE html>
<html>
<head>
    <title>Manage Recommendations</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/admin_dashboard2.css'); ?>">
</head>
<body>
    <div class="container">
        <h1>Manage Course Recommendations</h1>

        <!-- Flash Messages -->
        <?php if($this->session->flashdata('success')): ?>
            <div class="alert success"><?= $this->session->flashdata('success') ?></div>
        <?php endif; ?>
        <?php if($this->session->flashdata('error')): ?>
            <div class="alert error"><?= $this->session->flashdata('error') ?></div>
        <?php endif; ?>

        <!-- Add Recommendation Form -->
        <form method="post" action="<?= site_url('admin/add_recommendation'); ?>">
            <label>Select Course:</label>
            <select name="course_id" required>
                <?php foreach ($projects as $project): ?>
                    <option value="<?= $project->id ?>"><?= $project->name ?></option>
                <?php endforeach; ?>
            </select>

            <label>Recommendation Type:</label>
            <select name="type" required>
                <option value="collaborative">Collaborative Filtering</option>
                <option value="content">Content-Based Filtering</option>
                <option value="hybrid">Hybrid  Filtering</option>
            </select>

            <button type="submit">Add Recommendation</button>
        </form>

        <!-- Existing Recommendations -->
        <h2>Existing Recommendations</h2>
        <table>
            <tr>
                <th>Course</th>
                <th>Type</th>
            </tr>
            <?php foreach ($recommendations as $rec): ?>
                <tr>
                    <td><?= $rec->course_name ?></td>
                    <td><?= ucfirst($rec->type) ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
</body>
</html>
