<!DOCTYPE html>
<html>
<head>
    <title>AI Recommendations</title>
</head>
<body>
    <h1>Recommended Videos for You</h1>
    <?php if (!empty($recommended_courses)): ?>
        <?php foreach ($recommended_courses as $course): ?>
            <div>
                <h3><?= $course->title ?></h3>
                <p><?= $course->description ?></p>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No recommendations found.</p>
    <?php endif; ?>
</body>
</html>
