<?php
class Course_model extends CI_Model {

    public function get_all_courses() {
        return $this->db->get('courses')->result();
    }

    public function get_all_projects() {
        $query = $this->db->get('projects');
    
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return []; // Ensure it returns an empty array if no data
        }
    }
    public function get_project($course_id) {
        return $this->db->where('id', $course_id)->get('projects')->row();
    }
    
    public function get_projects_by_course($course_id) {
        return $this->db->where('id', $course_id)->get('projects')->result();
    }
    
    

    public function get_course($id) {
        $this->db->where('id', $id);
        return $this->db->get('courses')->row();
    }


    public function save_exam_result($data) {
        return $this->db->insert('exams', $data);
    }

    public function get_recommendations($student_id) {
        $this->db->select('courses.id, courses.title, courses.description');
        $this->db->from('recommendations');
        $this->db->join('courses', 'courses.id = recommendations.recommended_course_id');
        $this->db->where('recommendations.student_id', $student_id);
        $query = $this->db->get();
        
        return $query->result_array();
    }
    
}