<?php
defined('BASEPATH') or exit('No direct script access allowed');

class ClientModel extends CI_Model
{
    public function getProjects()
    {
        return $this->db->get('projects')->result_array();
    }

    public function getProposals()
    {
        return $this->db->get('proposals')->result_array();
    }

    public function getWalletBalance($client_id)
    {
        return $this->db->select('client_bal')->where('id', $client_id)->get('clients')->row('client_bal');
    }

    public function addProject($projectData)
    {
        $this->db->insert('projects', $projectData);
    }

    public function updateProposalStatus($proposalId, $status)
    {
        $this->db->where('id', $proposalId)->update('proposals', ['status' => $status]);
    }

    public function add_funds($client_id, $amount)
{
    // Check if the client already has a wallet
    $this->db->where('client_id', $client_id);
    $wallet = $this->db->get('wallet')->row();

    if ($wallet) {
        // Update the existing balance
        $this->db->set('balance', 'balance + ' . (float)$amount, FALSE);
        $this->db->where('client_id', $client_id);
        return $this->db->update('wallet');
    } else {
        // Create a new wallet entry
        $data = [
            'client_id' => $client_id,
            'balance' => (float)$amount
        ];
        return $this->db->insert('wallet', $data);
    }
}

}
