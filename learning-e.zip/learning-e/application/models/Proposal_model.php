<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Proposal_model extends CI_Model {

    // Function to add a new proposal from freelancer
    public function add_proposal($data)
    {
        $this->db->insert('freelancer_proposals', $data); // Insert proposal into freelancer_proposals table
        return $this->db->insert_id(); // Return the inserted proposal ID
    }

    // Function to get all proposals for a specific project
    public function get_proposals_for_project($project_id)
    {
        $this->db->where('project_id', $project_id);
        $query = $this->db->get('freelancer_proposals');
        return $query->result(); // Return all proposals for the project
    }

    // Function to accept a proposal (update proposal status to accepted)
    public function accept_proposal($proposal_id)
    {
        $data = array('status' => 'accepted');
        $this->db->where('id', $proposal_id);
        $this->db->update('freelancer_proposals', $data);
        return $this->db->affected_rows(); // Return the number of affected rows (1 if updated)
    }

    // Function to reject a proposal (update proposal status to rejected)
    public function reject_proposal($proposal_id)
    {
        $data = array('status' => 'rejected');
        $this->db->where('id', $proposal_id);
        $this->db->update('freelancer_proposals', $data);
        return $this->db->affected_rows(); // Return the number of affected rows (1 if updated)
    }

    // Function to get all proposals submitted by a specific freelancer
    public function get_freelancer_proposals($freelancer_id)
    {
        $this->db->where('freelancer_id', $freelancer_id);
        $this->db->order_by('created_at', 'DESC');
        $query = $this->db->get('freelancer_proposals');
        return $query->result(); // Return all proposals submitted by the freelancer
    }

    // Function to get the proposal details by proposal ID
    public function get_proposal_by_id($proposal_id)
    {
        $this->db->where('id', $proposal_id);
        $query = $this->db->get('freelancer_proposals');
        return $query->row(); // Return the proposal details
    }
}
