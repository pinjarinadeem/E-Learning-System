<?php
class Recommendation_model extends CI_Model {

    public function collaborative_filtering($student_id) {
        // Simplified collaborative filtering
        // Get popular courses among high scorers
        $courses = $this->db->query("
            SELECT course_id, COUNT(*) as count 
            FROM exams 
            WHERE score >= 70 
            GROUP BY course_id 
            ORDER BY count DESC 
            LIMIT 5
        ")->result();

        foreach ($courses as $course) {
            $data = array(
                'student_id' => $student_id,
                'course_id' => $course->course_id,
                'type' => 'collaborative'
            );
            $this->db->insert('recommendations', $data);
        }
    }

    public function content_based_filtering($student_id, $course_id) {
        // Get current course tags
        $current_course = $this->db->get_where('courses', array('id' => $course_id))->row();
        $tags = explode(',', $current_course->tags);

        // Find courses with similar tags
        $this->db->select('*');
        $this->db->from('courses');
        $this->db->where('id !=', $course_id);
        $this->db->like('tags', $tags[0]); // Simplified example
        $courses = $this->db->get()->result();

        foreach ($courses as $course) {
            $data = array(
                'student_id' => $student_id,
                'course_id' => $course->id,
                'type' => 'content'
            );
            $this->db->insert('recommendations', $data);
        }
    }

    public function save_recommendation($student_id, $course_id, $recommendation_type, $recommended_course_id) {
        // Check if recommended course exists
        $this->db->where('id', $recommended_course_id);
        $query = $this->db->get('courses');
        
        if ($query->num_rows() > 0) {
            $data = [
                'student_id' => $student_id,
                'course_id' => $course_id,
                'recommended_course_id' => $recommended_course_id,
                'recommendation_type' => $recommendation_type
            ];
            $this->db->insert('recommendations', $data);
        } else {
            log_message('error', 'Invalid recommended course ID: ' . $recommended_course_id);
        }
    }

    public function export_courses_to_csv() {
    $this->load->dbutil();
    $query = $this->db->query("SELECT id, title, description FROM courses");
    $csv_data = $this->dbutil->csv_from_result($query);
    file_put_contents(FCPATH . 'ml_data/courses.csv', $csv_data);
}

public function export_exams_to_csv() {
    $this->load->dbutil();
    $query = $this->db->query("SELECT id as exam_id, course_id FROM exams");
    $csv_data = $this->dbutil->csv_from_result($query);
    file_put_contents(FCPATH . 'ml_data/exams.csv', $csv_data);
}

public function export_exam_results_to_csv() {
    $this->load->dbutil();
    $query = $this->db->query("SELECT student_id, exam_id, score FROM student_results");
    $csv_data = $this->dbutil->csv_from_result($query);
    file_put_contents(FCPATH . 'ml_data/student_results.csv', $csv_data);
}

    
}