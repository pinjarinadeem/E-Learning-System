<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Freelancer_model extends CI_Model {

    public function register($data) {
        return $this->db->insert('freelancers', $data);
    }

    public function authenticate($email, $password) {
        $this->db->where('email', $email);
        $freelancer = $this->db->get('freelancers')->row();

        if ($freelancer && password_verify($password, $freelancer->password)) {
            return $freelancer;
        }
        return false;
    }

    public function get_profile($freelancer_id) {
        $this->db->where('id', $freelancer_id);
        $query = $this->db->get('freelancers');
        return $query->row_array();
    }

    public function get_available_projects() {
        $query = $this->db->get('client_projects');
        return $query->result_array();
    }

    public function get_all_projects() {
        // Fetch all projects where status is 'active' or 'open'
        $this->db->select('*');
        $this->db->from('projects'); // Table where projects are stored
        // $this->db->where('status', 'active'); // Fetch only active/open projects
        $query = $this->db->get();
    
        // Return results as an array of objects
        return $query->result();
    }
    

    public function get_wallet($freelancer_id) {
        $this->db->where('freelancer_id', $freelancer_id);
        $query = $this->db->get('freelancer_wallet');
        return $query->row_array();
    }

    public function get_published_projects()
    {
        $this->db->select('*');
        $this->db->from('projects');
        $this->db->where('status', 'published');
        return $this->db->get()->result();
    }

    public function insert_bid($data) {
        return $this->db->insert('bids', $data);
    }

    public function get_bids_by_project($project_id) {
        $this->db->select('bids.*, full_name AS freelancer_name'); // Select all bid data + freelancer name
        $this->db->from('bids'); // Main table is 'bids'
        $this->db->join('freelancers', 'freelancers.id = bids.freelancer_id', 'left'); // Join with 'freelancers' table
        $this->db->where('bids.client_id', $project_id); // Filter by client ID
    
        $query = $this->db->get();
        return $query->result(); // Return bid data with freelancer names
    }
    
     

    public function update_bid_status($bid_id, $status) {
        $this->db->where('id', $bid_id);
        return $this->db->update('bids', ['status' => $status]);
    }


    // Place a bid
    public function place_bid($freelancer_id, $project_id, $bid_amount)
    {
        $data = [
            'freelancer_id' => $freelancer_id,
            'project_id' => $project_id,
            'bid_amount' => $bid_amount,
            'status' => 'pending'
        ];
        return $this->db->insert('bids', $data);
    }

    // Submit a project
    public function submit_project($freelancer_id, $project_id, $submission_details)
    {
        $data = [
            'freelancer_id' => $freelancer_id,
            'project_id' => $project_id,
            'submission_details' => $submission_details,
            'submitted_at' => date('Y-m-d H:i:s'),
            'status' => 'submitted'
        ];
        return $this->db->insert('submissions', $data);
    }

    // Get wallet balance
    public function get_wallet_balance($freelancer_id)
    {
        $this->db->select('balance');
        $this->db->where('freelancer_id', $freelancer_id);
        $result = $this->db->get('wallet')->row();
        return $result ? $result->balance : 0.0;
    }

    // Withdraw funds
    public function withdraw_funds($freelancer_id, $amount)
    {
        $balance = $this->get_wallet_balance($freelancer_id);
        if ($balance >= $amount) {
            $this->db->set('balance', 'balance - ' . (float)$amount, FALSE);
            $this->db->where('freelancer_id', $freelancer_id);
            return $this->db->update('wallet');
        }
        return false;
    }

}
