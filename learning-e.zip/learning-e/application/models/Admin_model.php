<?php
class Admin_model extends CI_Model {

    public function login($email, $password) {
        $this->db->where('email', $email);
        $admin = $this->db->get('admins')->row();
        
        if ($admin && password_verify($password, $admin->password)) {
            $this->session->set_userdata('admin_logged_in', true);
            return true;
        }
        return false;
    }

    public function add_project($data) {
        return $this->db->insert('projects', $data);
    }

    public function add_exam($data) {
        return $this->db->insert('exams', $data);
    }

    public function add_question($data) {
        return $this->db->insert('questions', $data);
    }

    public function get_all_courses() {
        return $this->db->get('courses')->result();
    }

    public function get_exam_questions($exam_id) {
        return $this->db->where('exam_id', $exam_id)->get('questions')->result();
    }

    public function get_all_projects() {
        return $this->db->get('projects')->result();
    }
    
    public function get_all_recommendations() {
        $this->db->select('recommended_courses.*, projects.name as course_name');
        $this->db->from('recommended_courses');
        $this->db->join('projects', 'recommended_courses.course_id = projects.id');
        return $this->db->get()->result();
    }
    
    public function insert_recommendation($data) {
        return $this->db->insert('recommended_courses', $data);
    }
    
}