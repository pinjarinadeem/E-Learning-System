<?php
class Student_model extends CI_Model {

    public function register($data) {
        return $this->db->insert('students', $data);
    }

    public function login($email, $password) {
        $this->db->where('email', $email);
        $student = $this->db->get('students')->row();
        
        if ($student && password_verify($password, $student->password)) {
            return $student;
        }
        return false;
    }


        public function get_exam($exam_id) {
            return $this->db->where('course_id', $exam_id)->get('exams')->row();
        }
    
        public function get_exam_questions($exam_id) {
            return $this->db->where('exam_id', $exam_id)->get('questions')->result();
        }
    
        public function get_correct_option($question_id) {
            return $this->db->select('correct_option')->where('id', $question_id)->get('questions')->row()->correct_option;
        }
    
        public function save_exam_result($data) {
            return $this->db->insert('student_results', $data);
        }

        public function get_recommendations($type) {
            $this->db->select('recommended_courses.*, projects.name as course_name, projects.description');
            $this->db->from('recommended_courses');
            $this->db->join('projects', 'recommended_courses.course_id = projects.id');
            $this->db->where('recommended_courses.type', $type);
            return $this->db->get()->result();
        }
        

     public function get_ml_recommendations($student_id) {
    $command = escapeshellcmd("python application/ml_model/recommend.py $student_id");
    $output = shell_exec($command);

    if ($output === null || trim($output) === '') {
        log_message('error', 'ML script returned nothing.');
        return [];
    }

    $decoded = json_decode($output);
    if (json_last_error() !== JSON_ERROR_NONE) {
        log_message('error', 'JSON decode error: ' . json_last_error_msg());
        return [];
    }

    return $decoded;
}

public function get_collaborative_recommendations($student_id)
{
    $command = escapeshellcmd("python application/ml_model/recommend_collaborative.py $student_id");
    $output = shell_exec($command);

    if ($output === null || trim($output) === '') {
        log_message('error', 'Collaborative ML script returned nothing.');
        return [];
    }

    $decoded = json_decode($output);
    if (json_last_error() !== JSON_ERROR_NONE) {
        log_message('error', 'JSON decode error (collaborative): ' . json_last_error_msg());
        return [];
    }

    return $decoded;
}




    
    
}