<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Client_model extends CI_Model {

    public function register($data) {
        return $this->db->insert('clients', $data);
    }

    public function authenticate($email, $password) {
        $this->db->where('business_email', $email);
        $client = $this->db->get('clients')->row();

        if ($client && password_verify($password, $client->password)) {
            return $client;
        }
        return false;
    }
}
