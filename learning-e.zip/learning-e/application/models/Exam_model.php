<?php
class Exam_model extends CI_Model {
    // Get All Exams
    public function get_all_exams() {
        return $this->db->get('exams')->result();
    }

    public function get_exam_by_id($exam_id) {
        return $this->db->where('id', $exam_id)->get('exams')->row(); // Returns an object
    }
    

    public function get_exam($exam_id) {
        return $this->db->where('id', $exam_id)->get('exams')->row();
    }

    public function get_exam_questions($exam_id) {
        return $this->db->where('exam_id', $exam_id)->get('questions')->result();
    }


    // Add New Exam
    public function add_exam($exam_data) {
        return $this->db->insert('exams', $exam_data);
    }

    // Delete Exam
    public function delete_exam($exam_id) {
        $this->db->where('id', $exam_id);
        return $this->db->delete('exams');
    }

    // Add a Question to an Exam
    public function add_question($question_data) {
        return $this->db->insert('questions', $question_data);
    }

    // Get All Questions for a Specific Exam
    public function get_questions_by_exam($exam_id) {
        return $this->db->get_where('exam_questions', ['exam_id' => $exam_id])->result();
    }
}
?>