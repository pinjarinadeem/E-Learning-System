<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Project_model extends CI_Model {

    // Function to add a new project for the client
    public function add_project($data)
    {
        $this->db->insert('client_projects', $data); // Assuming 'client_projects' is the table for storing client projects
        return $this->db->insert_id(); // Return the inserted project ID
    }

    // Function to get all projects of a specific client
    public function get_client_projects($client_id)
    {
        $this->db->where('client_id', $client_id);
        $this->db->order_by('created_at', 'DESC'); // Sort by creation date
        $query = $this->db->get('client_projects');
        return $query->result(); // Return all projects of the client
    }

    // Function to get all proposals for a specific project
    public function get_proposals_for_project($project_id)
    {
        $this->db->where('project_id', $project_id);
        $query = $this->db->get('freelancer_proposals'); // Assuming 'freelancer_proposals' stores the proposals
        return $query->result(); // Return all proposals for the project
    }

    // Function to update the status of a project (Completed/Pending)
    public function update_project_status($project_id, $status)
    {
        $data = array('status' => $status);
        $this->db->where('id', $project_id);
        $this->db->update('client_projects', $data);
        return $this->db->affected_rows(); // Return the number of affected rows (1 if updated)
    }

    // Function to fetch a project by its ID
    public function get_project_by_id($project_id)
    {
        $this->db->where('id', $project_id);
        $query = $this->db->get('client_projects');
        return $query->row(); // Return the project if found
    }

    // Function to get all projects for freelancers (projects posted by clients)
    public function get_projects_for_freelancer()
    {
        $this->db->where('status', 'pending'); // Only show projects that are pending
        $this->db->order_by('created_at', 'DESC'); // Sort by creation date
        $query = $this->db->get('client_projects');
        return $query->result(); // Return all projects available for freelancers
    }

    // Function to get the project history (Completed/Pending) for freelancers
    public function get_freelancer_project_history($freelancer_id)
    {
        $this->db->select('cp.*, fp.status as proposal_status');
        $this->db->from('client_projects cp');
        $this->db->join('freelancer_proposals fp', 'fp.project_id = cp.id', 'left');
        $this->db->where('fp.freelancer_id', $freelancer_id);
        $query = $this->db->get();
        return $query->result(); // Return the project history for the freelancer
    }
}
